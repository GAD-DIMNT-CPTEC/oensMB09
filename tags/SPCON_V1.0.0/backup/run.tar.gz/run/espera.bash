#!/bin/bash -x

espera()
{

iq=2
while [ ${iq} -gt 0 ];do
sleep  18
iq=`qstat | grep pkubota | grep agu | wc -l`
echo $iq
done
}

espera
